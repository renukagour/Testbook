Hi there!

This is a static LinkedIn Page Clone
