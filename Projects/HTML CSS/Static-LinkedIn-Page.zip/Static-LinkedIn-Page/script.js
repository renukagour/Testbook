document.getElementById("search").addEventListener("click", function () {
    alert("lmao");
});