const mongoose = require('mongoose');
const Listing = require('../models/listing.js');
const initdata = require('./data.js');

const url = "your_MongoDB_url"


mongoose.connect(url, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
        console.log("Connected to DB");
        initDB();
    })
    .catch((err) => {
        console.log(`Error occurred in main function: ${err}`);
    });

const initDB = async () => {
    try {
        await Listing.deleteMany({});
        
        // Corrected this part
        initdata.data = initdata.data.map((obj) => ({
            ...obj,
            owner: '66af2316993f4c6d5705e81c'
        }));
        
        await Listing.insertMany(initdata.data);
        console.log("Data initialized");
    } catch (error) {
        console.log(`Error initializing data: ${error}`);
    }
};
